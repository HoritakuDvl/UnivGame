/*****************************************************************
ファイル名	: client_command.c
機能		: クライアントのコマンド処理
*****************************************************************/

#include"common.h"
#include"client_func.h"

static void SetIntData2DataBlock(void *data,int intData,int *dataSize);
static void SetCharData2DataBlock(void *data,char charData,int *dataSize);

static void RecvAllData(void);/*長尾　11/20*/

/*****************************************************************
関数名	: ExecuteCommand
機能	: サーバーから送られてきたコマンドを元に，
		  引き数を受信し，実行する
引数	: char	command		: コマンド
出力	: プログラム終了コマンドがおくられてきた時には0を返す．
		  それ以外は1を返す
*****************************************************************/
int ExecuteCommand(char command)
{
	int endFlag = 1;


	switch(command){
		case END_COMMAND:
			endFlag = 0;
			break;
		case ALL_COMMAND:
			RecvAllData();
			break;
	}

	return endFlag;
}

/*****************************************************************
関数名	: SendRightCommand
機能	: 右移動（ｄ）コマンドが押されたことを送る
引数	: なし
出力	: なし
*****************************************************************/
void SendRightCommand(void)
{   
	unsigned char	data[MAX_DATA];
	int dataSize;

	dataSize = 0;	
	/* コマンドのセット */
	SetCharData2DataBlock(data,RIGHT_COMMAND,&dataSize);

	/* データの送信 */
	SendData(data,dataSize);
}

/*****************************************************************
関数名	: SendLeftCommand
機能	: 左移動（a）コマンドが押されたことを送る
引数	: なし
出力	: なし
*****************************************************************/
void SendLeftCommand(void)
{
	unsigned char	data[MAX_DATA];
	int dataSize;

	dataSize = 0;
	/* コマンドのセット */	
	SetCharData2DataBlock(data,LEFT_COMMAND,&dataSize);

	/* データの送信 */
	SendData(data,dataSize);
}

/*****************************************************************
関数名	: SendJumpCommand
機能	: 上移動（ｗ）コマンドが押されたことを送る
引数	: なし
出力	: なし
*****************************************************************/
void SendJumpCommand(void)
{   
	unsigned char	data[MAX_DATA];
	int dataSize;

	dataSize = 0;
	/* コマンドのセット */
	SetCharData2DataBlock(data,JUMP_COMMAND,&dataSize);

	/* データの送信 */
	SendData(data,dataSize);
}
/*****************************************************************
関数名	: SendPointCommand
機能	: マウスポインタが移動したことを送る
引数	: なし
出力	: なし
*****************************************************************/
void SendPointCommand(int mouse_x,int mouse_y)
{   
	unsigned char	data[MAX_DATA];
	int dataSize;

	dataSize = 0;
	/* コマンドのセット */
	SetCharData2DataBlock(data,POINT_COMMAND,&dataSize);
	/* 長尾 12/03 マウスポインタのセット */ 
	SetIntData2DataBlock(data,mouse_x,&dataSize);
	SetIntData2DataBlock(data,mouse_y,&dataSize);

	/* データの送信 */
	SendData(data,dataSize);
}
/*****************************************************************
関数名	: SendShotCommand
機能	: shot（左クリック）コマンドが押されたことを送る
引数	: なし
出力	: なし
*****************************************************************/
void SendShotCommand(void)
{   
	unsigned char	data[MAX_DATA];
	int dataSize;

	dataSize = 0;
	/* コマンドのセット */
	SetCharData2DataBlock(data,SHOT_COMMAND,&dataSize);

	/* データの送信 */
	SendData(data,dataSize);
}
/*****************************************************************
関数名	: SendWeaponCommand
機能	: 武器変更（右クリック）コマンドが押されたことを送る
引数	: なし
出力	: なし
*****************************************************************/
void SendWeaponCommand(void)
{   
	unsigned char	data[MAX_DATA];
	int dataSize;

	dataSize = 0;
	/* コマンドのセット */
	SetCharData2DataBlock(data,WEAPON_COMMAND,&dataSize);

	/* データの送信 */
	SendData(data,dataSize);
}
/*****************************************************************
関数名	: SendEndCommand
機能	: プログラムの終了を知らせるために，
		  サーバーにデータを送る
引数	: なし
出力	: なし
*****************************************************************/
void SendEndCommand(void)
{
    unsigned char	data[MAX_DATA];
    int			dataSize;

    dataSize = 0;
    /* コマンドのセット */
    SetCharData2DataBlock(data,END_COMMAND,&dataSize);

    /* データの送信 */
    SendData(data,dataSize);
}

/*****************************************************************
関数名	: SetIntData2DataBlock
機能	: int 型のデータを送信用データの最後にセットする
引数	: void		*data		: 送信用データ
		  int		intData		: セットするデータ
		  int		*dataSize	: 送信用データの現在のサイズ
出力	: なし
*****************************************************************/
static void SetIntData2DataBlock(void *data,int intData,int *dataSize)
{
    int tmp;

    /* 引き数チェック */
    assert(data!=NULL);
    assert(0<=(*dataSize));

    tmp = htonl(intData);

    /* int 型のデータを送信用データの最後にコピーする */
    memcpy(data + (*dataSize),&tmp,sizeof(int));
    /* データサイズを増やす */
    (*dataSize) += sizeof(int);
}

/*****************************************************************
関数名	: SetCharData2DataBlock
機能	: char 型のデータを送信用データの最後にセットする
引数	: void		*data		: 送信用データ
		  int		intData		: セットするデータ
		  int		*dataSize	: 送信用データの現在のサイズ
出力	: なし
*****************************************************************/
static void SetCharData2DataBlock(void *data,char charData,int *dataSize)
{
    /* 引き数チェック */
    assert(data!=NULL);
    assert(0<=(*dataSize));

    /* char 型のデータを送信用データの最後にコピーする */
    *(char *)(data + (*dataSize)) = charData;
    /* データサイズを増やす */
    (*dataSize) += sizeof(char);
}
/*****************************************************************
関数名	: RecvAllData
機能	: 常時必要なデータを受信する
引数	: なし
出力	: なし
*****************************************************************/
static void RecvAllData(void)
{
	int pos;
	int i,j;
    	/* 各プレイヤーに対する引き数を受信する 背景座標 クライアントID 自機の移動座標を取得する timer HP 自機腕角度 各自機距離の差 弾の角度　各弾と自機の差*/
	RecvIntData(&pos);

	RecvIntData(&Player[pos].x);

	RecvIntData(&Player[pos].y);

	RecvIntData(&Back[pos].src_x);

	RecvIntData(&Back[pos].src_y);

	RecvIntData(&timer);

	for(i = 0;i < num_client;i++){
		RecvIntData(&Player[i].hp);

		RecvIntData(&PlayerArm[i].angle);

		RecvIntData(&Player[pos].distance_x[i]);

		RecvIntData(&Player[pos].distance_y[i]);

			for(j=0;j<MAX_BULLET;j++){
				RecvIntData(&Shot[i][j].B_angle);

				RecvIntData(&Shot[pos][j].distance_x[i]);

				RecvIntData(&Shot[pos][j].distance_y[i]);
			}
	}

	ClearScreen(pos,Back[pos].src_x,Back[pos].src_y);/*長尾　11/26 背景、フレームを表示する*/

	/* プレイヤー,腕,SHOT,HPを表示する */
	for(i = 0;i < num_client;i++){
		DrawPlayer(i,pos,Player[pos].distance_x[i],Player[pos].distance_y[i]);

		DrawPlayerArm(i,pos,Player[pos].distance_x[i],Player[pos].distance_y[i]);

		DrawPlayerHP(i,pos,Player[i].hp);

		for(j = 0;j < MAX_BULLET;j++){
			DrawShot(i,j,pos,Shot[pos][j].distance_x[i],Shot[pos][j].distance_y[i]);
		}
	}

	FlipScreen();/*長尾　11/26 コマンド処理後、Flip*/
}











