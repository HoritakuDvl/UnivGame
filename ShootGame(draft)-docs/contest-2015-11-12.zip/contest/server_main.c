/*****************************************************************
ファイル名	: server_main.c
機能		: サーバーのメインルーチン
*****************************************************************/

#include<SDL/SDL.h>
#include"server_common.h"

static Uint32 SignalHandler(Uint32 interval, void *param);
int num_client; /*inしたクライアントの人数*/
int timer; /*時刻*/

/*長尾*/
PlayerData Player[MAX_CLIENTS];
BackData Back[MAX_CLIENTS];
MouseData Mouse[MAX_CLIENTS];
ShotData Shot[MAX_CLIENTS][MAX_BULLET];

int main(int argc,char *argv[])
{
	int	num;
	int	endFlag = 1;

	/* 引き数チェック */
	if(argc != 2){
		fprintf(stderr,"Usage: number of clients\n");
		exit(-1);
	}
	if((num = atoi(argv[1])) < 0 ||  num > MAX_CLIENTS){
		fprintf(stderr,"clients limit = %d \n",MAX_CLIENTS);
		exit(-1);
	}
	
	/* SDLの初期化 */
	if(SDL_Init(SDL_INIT_TIMER) < 0) {
		printf("failed to initialize SDL.\n");
		exit(-1);
	}

	AllInit(num);
	
	/* クライアントとの接続 */
	if(SetUpServer(num) == -1){
		fprintf(stderr,"Cannot setup server\n");
		exit(-1);
	}
	
	/* 割り込み処理のセット */
	SDL_AddTimer(FPS,SignalHandler,NULL);
	
	/* メインイベントループ */
	while(endFlag){
		endFlag = SendRecvManager();
	};

	/* 終了処理 */
	Ending();

	return 0;
}

/*****************************************************************
関数名  : SignalHandler
機能    : 割り込み用関数 
引数    : Uint32	interval	: タイマー
	  void		*param		: 割り込み処理の引数
出力    : タイマーの次の間隔
*****************************************************************/
static Uint32 SignalHandler(Uint32 interval, void *param)
{
	int pos;

	timer++; /*FPS 0,2秒毎*/

	for(pos = 0; pos < num_client; pos++){
		GetGravity(pos);
		GetSendAll(pos);
	}

	return interval;
}


/*****************************************************************
関数名	: AllInit
機能	: キャラやフレームを初期配置にセットする
引数	: なし
出力	: なし
*****************************************************************/
void AllInit(int num)
{
	int i,j;

	num_client = num; /*長尾 12/02　クライアントの人数を格納*/

	/* 自機の初期描写　長尾11/12*/
	for(i=0;i<num_client;i++){
		Player[i].src_rect_player.w = 48;
		Player[i].src_rect_player.h = 21;
		Player[i].dst_rect_player.x = 50;
		Player[i].dst_rect_player.y = 400;
		Player[i].hp = 25;
		Player[i].x = WINDOW_WIDTH/2;
		Player[i].y = WINDOW_HEIGHT/2;

		Back[i].src_x = 0;
		Back[i].src_y = 0;
		/* 弾の初期化　長尾12/05*/
		for(j = 0;j < MAX_BULLET;j++){
			Shot[i][j].src_rect_shot.w = 22;
			Shot[i][j].src_rect_shot.h = 22;
			Shot[i][j].dst_rect_shot.x = -100;
			Shot[i][j].dst_rect_shot.y = -100;
		}
	}

	Back[0].src_x = 0;//今だけコンテスト
	Back[0].src_y = 0;
	Back[1].src_x = 400;
	Back[1].src_y = 0;
	Back[2].src_x = 800;
	Back[2].src_y = 0;
	Back[3].src_x = 1200;
	Back[3].src_y = 0;
}








