/*****************************************************************
ファイル名	: client_main.c
機能		: クライアントのメインルーチン
*****************************************************************/

#include"common.h"
#include"client_func.h"

/*長尾 11/21 初期宣言*/
PlayerData Player[MAX_CLIENTS];
PlayerArmData PlayerArm[MAX_CLIENTS];
BackData Back[MAX_CLIENTS];
FlameData Flame;
MouseData Mouse[MAX_CLIENTS];
ShotData Shot[MAX_CLIENTS][MAX_BULLET];
int num_client; /*inしたクライアントの人数*/
int timer; /*時刻*/
int order; /*クライアントID*/

int main(int argc,char *argv[])
{
    int		num;
    char	name[MAX_CLIENTS][MAX_NAME_SIZE];
    int		endFlag=1;
    char	localHostName[]="localhost";
    char	*serverName;
    int		clientID;

    /* 引き数チェック */
    if(argc == 1){
    	serverName = localHostName;
    }
    else if(argc == 2){
    	serverName = argv[1];
    }
    else{
		fprintf(stderr, "Usage: %s, Cannot find a Server Name.\n", argv[0]);
		return -1;
    }

    /* サーバーとの接続 */
    if(SetUpClient(serverName,&clientID,&num,name)==-1){
		fprintf(stderr,"setup failed : SetUpClient\n");
		return -1;
	}
    /* ウインドウの初期化 */
	if(InitWindows(clientID,num,name)==-1){
		fprintf(stderr,"setup failed : InitWindows\n");
		return -1;
	}


    /* メインイベントループ */
    while(endFlag){
		WindowEvent(num);
		endFlag = SendRecvManager();
    };

    /* 終了処理 */
	DestroyWindow();
	CloseSoc();

    return 0;
}

