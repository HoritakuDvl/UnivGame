/*****************************************************************
ファイル名	: server_common.h
機能		: サーバーで使用する定数の宣言を行う
*****************************************************************/

#ifndef _SERVER_COMMON_H_
#define _SERVER_COMMON_H_

#include"common.h"

/* server_main.c*/
extern void AllInit(int num);
extern int GetGravity(int pos); /*長尾 11/26 重力*/
extern int GetSendAll(int pos); /*長尾 11/26 プレーヤーのID及び座標*/

#define ALL_CLIENTS	-1   /* 全クライアントにデータを送る時に使用する */
#define GRAVITY		1    /* 11/26 長尾　重力 */
#define JUMP_POWER	33  /* 11/26 長尾　ジャンプ力 */
#define PI 		3.141592 /* 円周率 */
#define FPS 		20 /* データを送るスピード　数が大きければ動きは緩慢になる */

#endif
