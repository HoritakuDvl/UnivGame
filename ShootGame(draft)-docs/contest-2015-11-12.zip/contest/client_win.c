/*****************************************************************
ファイル名	: client_win.c
機能		: クライアントのユーザーインターフェース処理
*****************************************************************/
/* 長尾 11/12 ヘッダーに移動
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_gfxPrimitives.h> */
#include"common.h"
#include"client_func.h"

static SDL_Surface *gMainWindow;
static int right_press_count = 0; /*長尾 11/26*/
static int left_press_count = 0;
static TTF_Font* font;	// TrueTypeフォントデータへのポインタ 長尾12/08
static SDL_Color black;	// フォントの色を指定するための構造体

/*****************************************************************
関数名	: InitWindows
機能	: メインウインドウの表示，設定を行う
引数	: int	clientID		: クライアント番号
	  int	num				: 全クライアント数
出力	: 正常に設定できたとき0，失敗したとき-1
*****************************************************************/
int InitWindows(int clientID,int num,char name[][MAX_NAME_SIZE])
{
	int i;
	char *s;

	order = clientID; /*長尾 12/09 クライアントIDをorderに格納*/	
	num_client = num; /*長尾 11/26　クライアントの人数を格納*/

    	/* 引き数チェック */
    	assert(0<num && num<=MAX_CLIENTS);
	
	/* SDLの初期化 */
	if(SDL_Init(SDL_INIT_VIDEO) < 0) {
		printf("failed to initialize SDL.\n");
		return -1;
	}
	
	/* メインのウインドウを作成する */
	if((gMainWindow = SDL_SetVideoMode(WINDOW_WIDTH,WINDOW_HEIGHT, 32, SDL_SWSURFACE)) == NULL) {
		printf("failed to initialize videomode.\n");
		return -1;
	}
	/* ウインドウのタイトルをセット */
	SDL_WM_SetCaption("koukigame",NULL);
	
	AllInit(); /*長尾　11/21*/
	
	return 0;
}

/*****************************************************************
関数名	: DestroyWindow
機能	: SDLを終了する
引数	: なし
出力	: なし
*****************************************************************/
void DestroyWindow(void)
{
	SDL_Quit();
}

/*****************************************************************
関数名	: WindowEvent
機能	: メインウインドウに対するイベント処理を行う
引数	: int		num		: 全クライアント数
出力	: なし
*****************************************************************/
void WindowEvent(int num)
{
	SDL_Event event;
	Uint8 *keys;
	keys = SDL_GetKeyState(NULL);

	/* 引き数チェック */
    	assert(0<num && num<=MAX_CLIENTS);
	SDL_PollEvent(NULL);

	 if(Player[order].hp >= 0){//ここは後で直す　ｈｐが０では終了できない
		if(SDL_PollEvent(&event)){
			switch(event.type){
				case SDL_KEYDOWN:	
					if(event.key.keysym.sym == SDLK_w){
						SendJumpCommand();
					}
					if(event.key.keysym.sym == SDLK_ESCAPE){
						SendEndCommand();
					}
				break;
				case SDL_MOUSEMOTION: // マウスが移動した時
					SendPointCommand(event.motion.x, event.motion.y);
				break;
				case SDL_MOUSEBUTTONDOWN: //マウスでクリックしたとき
					if(event.button.button == SDL_BUTTON_LEFT){ //左クリック
						SendShotCommand();
				}
					if(event.button.button == SDL_BUTTON_RIGHT){ //右クリック
						SendWeaponCommand();
				}
			}
		}

		if(keys[SDLK_d]==SDL_PRESSED){//右
			right_press_count += 1;
			if(right_press_count % 9 == 1){
				SendRightCommand();
			}
		}

		else if(keys[SDLK_a]==SDL_PRESSED){//左
			left_press_count += 1;
			if(left_press_count % 9 == 1){
				SendLeftCommand();
			}
		}
	}

}

/*****************************************************************
関数名	: DrawPlayer
機能	: メインウインドウに各プレイヤーを表示する(長尾 11/20)
引数	: int		i			: for文のi
	  int		pos			: クライアントID
	  int		distance_x		: 各プレイヤーとの x 座標の距離差
	　int		distance_y		: 各プレイヤーとの y 座標の距離差
出力	: なし
*****************************************************************/
void DrawPlayer(int i,int pos,int distance_x,int distance_y)
{
	Player[i].dst_rect_other_player.x = WINDOW_WIDTH/2 + distance_x;
	Player[i].dst_rect_other_player.y = WINDOW_HEIGHT/2 + distance_y;
	Player[i].dst_rect_ikon.x = WINDOW_WIDTH/2 + distance_x+12;//自機上のアイコン
	Player[i].dst_rect_ikon.y = WINDOW_HEIGHT/2 + distance_y-30;
	SDL_BlitSurface(Player[i].ziki,&Player[i].src_rect_player,gMainWindow,&Player[i].dst_rect_other_player);
	SDL_BlitSurface(Player[i].ikon,NULL,gMainWindow,&Player[i].dst_rect_ikon);
}
/*****************************************************************
関数名	: DrawPlayerArm
機能	: メインウインドウに各プレーヤーの腕を表示する(長尾 11/20)
引数	: int		i		: 各プレイヤーのクライアントID（ただし、自分も含む）
	  int		pos		: 自分のクライアントID
	　int		distance_x	: 自分と相手の距離差ｘ
 	  int		distance_y	: 自分と相手の距離差ｙ
出力	: なし
*****************************************************************/
void DrawPlayerArm(int i,int pos,int distance_x,int distance_y)
{
	PlayerArm[i].arm_resized = rotozoomSurface(PlayerArm[i].arm, PlayerArm[i].angle, 1, 1);//腕を回転させる
	PlayerArm[i].dst_rect_player_arm.x = WINDOW_WIDTH/2 + distance_x+10;
	PlayerArm[i].dst_rect_player_arm.y = WINDOW_HEIGHT/2 + distance_y+20;
	SDL_BlitSurface(PlayerArm[i].arm_resized,&PlayerArm[i].src_rect_player_arm,gMainWindow,&PlayerArm[i].dst_rect_player_arm);
	SDL_FreeSurface(PlayerArm[i].arm_resized);//サーフェイス解放
}
/*****************************************************************
関数名	: DrawShot
機能	: メインウインドウにSHOTを表示する(長尾 12/04)
引数	: int		i		: 各プレイヤーのクライアントID（ただし、自分も含む）
	　int		j		: 描く弾の配列番号
	  int		pos		: 自分のクライアントID
	　int		distance_x	: 自分と弾の距離差ｘ
 	  int		distance_y	: 自分と弾の距離差ｙ
出力	: なし
*****************************************************************/
void DrawShot(int i,int j,int pos,int distance_x,int distance_y)
{

	Shot[i][j].shot_resized = rotozoomSurface(Shot[i][j].shot,Shot[i][j].B_angle, 1, 1);//弾を回転させる
	Shot[i][j].dst_rect_shot.x = WINDOW_WIDTH/2 + distance_x;
	Shot[i][j].dst_rect_shot.y = WINDOW_HEIGHT/2 + distance_y;
	SDL_BlitSurface(Shot[i][j].shot_resized,&Shot[i][j].src_rect_shot,gMainWindow,&Shot[i][j].dst_rect_shot);
	SDL_FreeSurface(Shot[i][j].shot_resized );//サーフェイス解放
}
/*****************************************************************
関数名	: DrawPlayerHP
機能	: メインウインドウにHPを表示する(長尾 12/09)
引数	: int		i		: 各プレイヤーのクライアントID（ただし、自分も含む）
	  int		pos		: 自分のクライアントID
	　int		hp		: 体力
出力	: なし
*****************************************************************/
void DrawPlayerHP(int i,int pos,int hp)
{
	int j = 0;
	
	/*自分のHP*/
	if(i == 0 && pos == 0 && hp > 0) boxColor(gMainWindow, 100, 545, (100 + hp * 4), 565, 0xff0000ff);
	if(i == 1 && pos == 1 && hp > 0) boxColor(gMainWindow, 100, 545, (100 + hp * 4), 565, 0x1200ffff);
	if(i == 2 && pos == 2 && hp > 0) boxColor(gMainWindow, 100, 545, (100 + hp * 4), 565, 0x24ff00ff);
	if(i == 3 && pos == 3 && hp > 0) boxColor(gMainWindow, 100, 545, (100 + hp * 4), 565, 0xffd800ff);

	/*他プレイヤーのミニHP*/
	if(i == 0 && hp > 0) boxColor(gMainWindow, 494, 533, (494 + hp * 1), 537, 0xff0000ff);
	if(i == 1 && hp > 0) boxColor(gMainWindow, 572, 533, (572 + hp * 1), 537, 0x1200ffff);
	if(i == 2 && hp > 0) boxColor(gMainWindow, 650, 533, (650 + hp * 1), 537, 0x24ff00ff);
	if(i == 3 && hp > 0) boxColor(gMainWindow, 726, 533, (726 + hp * 1), 537, 0xffd800ff);

	if(Player[pos].hp <= 0) SDL_BlitSurface(Flame.lose,NULL,gMainWindow,NULL);


}

/*****************************************************************
関数名	: ClearScreen()
機能	: 画面を初期化
引数	: なし
出力	: なし
*****************************************************************/
void ClearScreen(int pos,int src_x,int src_y)
{
	int i = 0;
	char name[10];

	Back[pos].src_rect_back.x = src_x;
	Back[pos].src_rect_back.y = src_y;
	SDL_BlitSurface(Back[pos].back,&Back[pos].src_rect_back,gMainWindow,&Back[pos].dst_rect_back);

	SDL_BlitSurface(Flame.flame,&Flame.src_rect_flame,gMainWindow,&Flame.dst_rect_flame);

	/*for(i = 0;i < num_client;i++){//キルログ描写
		if(Player[i].hp < 0){
			SDL_BlitSurface(Flame.log,NULL,gMainWindow,&Flame.dst_rect_log);
			SDL_BlitSurface(Flame.winlog,NULL,gMainWindow,&Flame.dst_rect_winlog);
			SDL_BlitSurface(Flame.loselog,NULL,gMainWindow,&Flame.dst_rect_loselog);	
		}
	}*/

	for(i = 0;i<num_client;i++){
		sprintf(name, "%s", Player[i].name);
		Player[i].names = TTF_RenderUTF8_Blended(font, name, black);
		SDL_BlitSurface(Player[i].names, NULL, gMainWindow, &Player[i].dst_rect_name);
	}
}
/*****************************************************************
関数名	: FlipScreen(
機能	: 画面をFlipする
引数	: なし
出力	: なし
*****************************************************************/
int FlipScreen()
{
	SDL_Flip(gMainWindow);
}
/*****************************************************************
関数名	: AllInit
機能	: キャラやフレームを初期配置にセットする
引数	: なし
出力	: なし
*****************************************************************/
AllInit()
{

	int i,j;
	/* 自機の初期化　長尾11/12*/
	for(i=0;i<num_client;i++){
		Player[i].src_rect_player.w = 48;
		Player[i].src_rect_player.h = 48;
		Player[i].dst_rect_player.x = 50;
		Player[i].dst_rect_player.y = 400;
		Player[i].x = 50;
		Player[i].y = 400;
		Player[i].ziki = IMG_Load("player.png");
		Player[i].dst_rect_name.x = 496 + (78 * i);//名前初期位置
		Player[i].dst_rect_name.y = 545;
		Player[i].dst_rect_ikon.x = 0;//アイコン初期化
		Player[i].dst_rect_ikon.y = 0;
		Player[0].ikon = IMG_Load("1P.png");
		Player[1].ikon = IMG_Load("2P.png");
		Player[2].ikon = IMG_Load("3P.png");
		Player[3].ikon = IMG_Load("4P.png");
		/* 背景の初期化　長尾11/21*/
		Back[i].back = IMG_Load("Back1.gif");
		Back[i].src_rect_back.w = 1600;
		Back[i].src_rect_back.h = 1066;
		Back[i].dst_rect_back.x = 0;
		Back[i].dst_rect_back.y = 0;
		/* 自機腕の初期化*/
		PlayerArm[i].src_rect_player_arm.w = 22;
		PlayerArm[i].src_rect_player_arm.h = 22;
		PlayerArm[i].dst_rect_player_arm.x = 50;
		PlayerArm[i].dst_rect_player_arm.y = 400;
		PlayerArm[i].arm = IMG_Load("weapon.png");
		/* 弾の初期化　長尾12/05*/
		for(j = 0;j < MAX_BULLET;j++){
			Shot[i][j].src_rect_shot.w = 22;
			Shot[i][j].src_rect_shot.h = 22;
			Shot[i][j].dst_rect_shot.x = -100;
			Shot[i][j].dst_rect_shot.y = -100;
			Shot[i][j].shot = IMG_Load("shot.png");
		}

	}
	

	/* フレームの初期描写　長尾11/21*/
	Flame.flame = IMG_Load("Flame.png");
	Flame.dst_rect_flame.x = 0;
	Flame.dst_rect_flame.y = 475;
	Flame.src_rect_flame.w = 470 + (80 * num_client);
	Flame.src_rect_flame.h = 120;
	/* キルログの初期描写　長尾12/09*/
	Flame.win = IMG_Load("win.png"); //今だけ画像
	Flame.lose = IMG_Load("lose.png"); //今だけ画像
	Flame.log = IMG_Load("log.png"); //キルログ画像
	/*Flame.p1log = IMG_Load("1Plog.png"); //1p画像
	Flame.p2log = IMG_Load("2Plog.png"); //2p画像
	Flame.p3log = IMG_Load("3Plog.png"); //3p画像
	Flame.p4log = IMG_Load("4Plog.png"); //4p画像*/
	Flame.dst_rect_log.x = 20;//ログ描写座標
	Flame.dst_rect_log.y = 50;
	Flame.dst_rect_winlog.x = 40;//ログ　倒した方の描写座標
	Flame.dst_rect_winlog.y = 60;
	Flame.dst_rect_loselog.x = 90;//ログ　倒された方の描写座標
	Flame.dst_rect_loselog.y = 60;


	/* フォント初期化　長尾12/08*/
	TTF_Init();
	font = TTF_OpenFont("kochi-gothic-subst.ttf", 13); // フォント使用
	black.r = 0x00;
	black.g = 0x00;
	black.b = 0x00;

}
