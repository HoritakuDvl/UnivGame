/*****************************************************************
ファイル名	: server_command.c
機能		: サーバーのコマンド処理
*****************************************************************/

#include"server_common.h"
#include"server_func.h"

static void SetIntData2DataBlock(void *data,int intData,int *dataSize);
static void SetCharData2DataBlock(void *data,char charData,int *dataSize);
static int GetRandomInt(int n);
static void GetJump(int pos); /*長尾 11/26*/
static void GetRight(int pos); /*長尾 11/26 右*/
static void GetLeft(int pos); /*長尾 11/26　左*/
static void GetUP(int pos); /*長尾 11/26　上*/
static void GetMouseMove(int pos); /*長尾 12/03　マウスポインタ*/
static void DifferntDistance(int pos); /*長尾 12/04 各プレーヤーの距離差を測る*/
static void DifferntDistanceShot(int pos); /*長尾 12/04 各プレーヤーとSHOTの距離差を測る*/
static void GetShot(int pos); /*長尾 12/05 SHOT*/
static void ShotMove(int pos); /*長尾 12/05 セットされたSHOTの移動を管理*/
static void GetWeapon(int pos); /*長尾 12/05 武器*/
static void HitJudge(int pos); /*長尾 12/09 弾との当たり判定*/

/*****************************************************************
関数名	: ExecuteCommand
機能	: クライアントから送られてきたコマンドを元に，
		  引き数を受信し，実行する
引数	: char	command		: コマンド
	  int	pos		: コマンドを送ったクライアント番号
出力	: プログラム終了コマンドが送られてきた時には0を返す．
		  それ以外は1を返す
*****************************************************************/
int ExecuteCommand(char command,int pos)
{
	unsigned char data[MAX_DATA];
	int dataSize,intData;
	int endFlag = 1;

	/* 引き数チェック */
	assert(0<=pos && pos<MAX_CLIENTS);

	switch(command){
		case END_COMMAND:
			dataSize = 0;
			/* コマンドのセット */
			SetCharData2DataBlock(data,command,&dataSize);
			/* 全ユーザーに送る */
			SendData(ALL_CLIENTS,data,dataSize);
			endFlag = 0;
			break;
		case LEFT_COMMAND://左（ａ）が押された	
			GetLeft(pos);
			break;
		case RIGHT_COMMAND://右（ｄ）が押された 
			GetRight(pos);
			break;
		case JUMP_COMMAND://上（ｗ）が押された
			if(Player[pos].jumpflag == 0){	
				Player[pos].jump = JUMP_POWER;
			}
			Player[pos].jumpflag = 1;
			break;
		case POINT_COMMAND://マウスポインタが移動した
			GetMouseMove(pos);
			break;
		case SHOT_COMMAND://左クリック
			GetShot(pos);
			break;
		case WEAPON_COMMAND://右クリック
			GetWeapon(pos);
			break;
		default:
			/* 未知のコマンドが送られてきた */
			fprintf(stderr,"0x%02x is not command!\n",command);
	}
	return endFlag;
}


/*****
static
*****/
/*****************************************************************
関数名	: SetIntData2DataBlock
機能	: int 型のデータを送信用データの最後にセットする
引数	: void		*data		: 送信用データ
	  int		intData		: セットするデータ
	  int		*dataSize	: 送信用データの現在のサイズ
出力	: なし
*****************************************************************/
static void SetIntData2DataBlock(void *data,int intData,int *dataSize)
{
    int tmp;

    /* 引き数チェック */
    assert(data!=NULL);
    assert(0<=(*dataSize));

    tmp = htonl(intData);

    /* int 型のデータを送信用データの最後にコピーする */
    memcpy(data + (*dataSize),&tmp,sizeof(int));
    /* データサイズを増やす */
    (*dataSize) += sizeof(int);
}

/*****************************************************************
関数名	: SetCharData2DataBlock
機能	: char 型のデータを送信用データの最後にセットする
引数	: void		*data		: 送信用データ
	  int		intData		: セットするデータ
	  int		*dataSize	: 送信用データの現在のサイズ
出力	: なし
*****************************************************************/
static void SetCharData2DataBlock(void *data,char charData,int *dataSize)
{
    /* 引き数チェック */
    assert(data!=NULL);
    assert(0<=(*dataSize));

    /* int 型のデータを送信用データの最後にコピーする */
    *(char *)(data + (*dataSize)) = charData;
    /* データサイズを増やす */
    (*dataSize) += sizeof(char);
}
/*****************************************************************
関数名	: GetSendAll　長尾 11/26
機能	: プレーヤーの座標、クライアント番号を送る
引数	: int		pos	:クライアントID
出力	: 
*****************************************************************/
int GetSendAll(int pos)
{
	unsigned char data[MAX_DATA];
	int dataSize,intData;
	int i,j;

	/*常時送るコマンド*/
	dataSize = 0;

	/*長尾 11/26 プレイヤーｙ座標をプレイヤーjumpを加算*/
	GetJump(pos);

	/*長尾 12/04 プレイヤーの距離の差を測る*/
	DifferntDistance(pos);

	/*長尾 12/05 セットされたshotの移動を管理*/
	ShotMove(pos);

	/*長尾 12/05 セットされたshotとプレーヤーとの距離の差を測る*/
	DifferntDistanceShot(pos);

	/*長尾 12/09 セットされたshotの当たり判定を取る*/
	HitJudge(pos);

	/*******ここからクライアントに送るデータ*******/

	/* コマンドのセット */
	SetCharData2DataBlock(data,ALL_COMMAND,&dataSize);

	/*長尾 11/25 プレイヤーIDをintDataに格納 プレイヤーIDを送る*/
	SetIntData2DataBlock(data,pos,&dataSize);

	/*長尾 11/20 プレイヤーの座標をintDataに格納 プレイヤーx座標を送る*/
	SetIntData2DataBlock(data,Player[pos].x,&dataSize);
	
	/*長尾 11/20 プレイヤーの座標をintDataに格納 プレイヤーｙ座標を送る*/
	SetIntData2DataBlock(data,Player[pos].y,&dataSize);

	/*長尾 11/26 背景座標をintDataに格納 背景x座標を送る*/
	SetIntData2DataBlock(data,Back[pos].src_x,&dataSize);
	
	/*長尾 11/26 背景の座標をintDataに格納 背景ｙ座標を送る*/
	SetIntData2DataBlock(data,Back[pos].src_y,&dataSize);

	/*長尾 12/09 timer時刻をintDataに格納 timer時刻を送る*/
	SetIntData2DataBlock(data,timer,&dataSize);


	/*長尾 12/04 プレイヤーの距離の差をintDataに格納 プレイヤーの距離の差を送る*/
	for(i = 0;i < num_client;i++){
		/*長尾 12/09 HPをintDataに格納 各プレイヤーのHPを送る*/
		SetIntData2DataBlock(data,Player[i].hp,&dataSize);
		/*長尾 12/03 腕の角度をintDataに格納 各プレイヤー腕の角度を送る*/
		SetIntData2DataBlock(data,Mouse[i].B_angle,&dataSize);
		/*長尾 12/03 プレーヤーとの距離の差を送る*/
		SetIntData2DataBlock(data,Player[pos].distance_x[i],&dataSize);

		SetIntData2DataBlock(data,Player[pos].distance_y[i],&dataSize);

		for(j=0;j<MAX_BULLET;j++){
		/*長尾 12/05 shotの角度をintDataに格納 shotの角度を送る*/
			SetIntData2DataBlock(data,Shot[i][j].B_angle,&dataSize);
		/*長尾 12/05 プレーヤーとshotとの距離の差を送る*/
			SetIntData2DataBlock(data,Shot[pos][j].distance_x[i],&dataSize);

			SetIntData2DataBlock(data,Shot[pos][j].distance_y[i],&dataSize);
		}
	}

	/* 全ユーザーに送る */
	//SendData(ALL_CLIENTS,data,dataSize);
	for(i = 0;i < num_client;i++)
		if(i == pos){
			SendData(i,data,dataSize);
		}
}
/*****************************************************************
関数名	: GetGravity　長尾 11/26
機能	: プレーヤーに重力を与える
引数	: int	pos	: クライアントID
出力	: ｙ座標
*****************************************************************/
int GetGravity(int pos)
{	
	if(Back[pos].src_y  < (STAGE_WIDTH - WINDOW_HEIGHT-48)){
		Back[pos].src_y += Back[pos].ay;
		Back[pos].ay += GRAVITY;
	}
	else if(Back[pos].src_y >= (STAGE_WIDTH - WINDOW_HEIGHT-48)){
		Back[pos].src_y = STAGE_WIDTH - WINDOW_HEIGHT-48;
		Back[pos].ay = 0;
	}
	Player[pos].y  = (WINDOW_HEIGHT/2);
}
/*****************************************************************
関数名	: GetJump　長尾 11/26
機能	: プレーヤーにジャンプ力を加える
引数	: クライアントID
出力	: なし
*****************************************************************/
void GetJump(int pos){
	if(Player[pos].jump > 0){
		Back[pos].src_y  -= Player[pos].jump;
		Player[pos].jump -= GRAVITY;
	}
	else if(Player[pos].jump <= 0){
		Player[pos].jump = 0;
		Player[pos].jumpflag = 0;
	}
	Player[pos].y = WINDOW_HEIGHT/2;
}
/*****************************************************************
関数名	: GetRight　長尾 11/26
機能	: プレイヤー座標と背景描写座標を右に
引数	: クライアントID
出力	: なし
*****************************************************************/
void GetRight(int pos){
	if(Back[pos].src_x <= STAGE_WIDTH -50)
		Back[pos].src_x  += 1;
	if(Back[pos].src_x > STAGE_WIDTH -50)
		Back[pos].src_x  = STAGE_WIDTH -50;
	Player[pos].x = (WINDOW_WIDTH/2);
}
/*****************************************************************
関数名	: GetLeft　長尾 11/26
機能	: プレイヤー座標と背景描写座標を左に
引数	: クライアントID
出力	: なし
*****************************************************************/
void GetLeft(int pos){
	if(Back[pos].src_x >= 0)
		Back[pos].src_x  -= 1;
	if(Back[pos].src_x < 0)
		Back[pos].src_x  = 0;
	Player[pos].x = (WINDOW_WIDTH/2);	
}

/*****************************************************************
関数名	: GetMouseMove　長尾 12/03
機能	: マウスポインタの座標を受け取る
引数	: クライアントID
出力	: なし
*****************************************************************/
void GetMouseMove(int pos){

	int intData;

	/*長尾 11/12 ポインタｘ座標をintDataに格納*/
	RecvIntData(pos,&intData);
	Mouse[pos].x = intData;

	/*長尾 11/12 ポインタｙ座標をintDataに格納*/
	RecvIntData(pos,&intData);
	Mouse[pos].y = intData;

	printf("Player[pos].y %d\n",Player[pos].y);
	printf("Mouse[pos].y %d\n",Mouse[pos].y);
	printf("Back[pos].src_y %d\n",Back[pos].src_y);
	printf("Mouse[pos].y + Back[pos].src_y %d\n\n",Mouse[pos].y + Back[pos].src_y);

	printf("Player[pos].x %d\n",Player[pos].x);
	printf("Mouse[pos].x %d\n",Mouse[pos].x);
	printf("Back[pos].src_x %d\n",Back[pos].src_x);
	printf("Mouse[pos].x + Back[pos].src_x %d\n\n",Mouse[pos].x + Back[pos].src_x);

	Mouse[pos].A_angle = atan2(Player[pos].y - Mouse[pos].y , Player[pos].x - Mouse[pos].x); //弧度法の角度を取る double
	Mouse[pos].B_angle = (-Mouse[pos].A_angle/PI) * 180; //度数法の角度に変える int
		

}
/*****************************************************************
関数名	: DifferntDistance　長尾 12/04
機能	: 各プレーヤーの距離差を測る
引数	: クライアントID
出力	: なし
*****************************************************************/
void DifferntDistance(int pos){

	int i;
	for(i=0;i<num_client;i++){
		Player[pos].distance_x[i] = Back[i].src_x - Back[pos].src_x;
		Player[pos].distance_y[i] = Back[i].src_y - Back[pos].src_y;
	}
}

/*****************************************************************
関数名	: GetShot 長尾　12/05　
機能	: SHOTのセット
引数	: クライアントID
出力	: なし
*****************************************************************/
void GetShot(int pos){

	int i;
        for(i=0;i<MAX_BULLET;i++){
        	if(Shot[pos][i].flag == 0){
        	        Shot[pos][i].flag = 1;
        	        Shot[pos][i].x = Back[pos].src_x + 15;
        	        Shot[pos][i].y = Back[pos].src_y + 15;
        	        Shot[pos][i].A_angle = Mouse[pos].A_angle;//度数法
       	        	Shot[pos][i].B_angle = Mouse[pos].B_angle;//弧度法
        	        break;
		}
	}

}

/*****************************************************************
関数名	: ShotMove 長尾　12/05　
機能	: セットされたSHOTの移動を管理
引数	: クライアントID
出力	: なし
*****************************************************************/
void ShotMove(int pos){

	int j;
        for(j=0;j<MAX_BULLET;j++){
        	if(Shot[pos][j].flag == 1){
        	        Shot[pos][j].x += -20*cos(Shot[pos][j].A_angle); //20が弾のスピード
        	        Shot[pos][j].y += -20*sin(Shot[pos][j].A_angle);
		}
	}

}

/*****************************************************************
関数名	: DifferntDistanceShot　長尾 12/04
機能	: 各プレーヤーとShotの距離差を測る
引数	: クライアントID
出力	: なし
*****************************************************************/
void DifferntDistanceShot(int pos){

	int i,j;
	for(i=0;i<num_client;i++){
		for(j=0;j<MAX_BULLET;j++){
			Shot[pos][j].distance_x[i] = Shot[i][j].x  - Back[pos].src_x;
			Shot[pos][j].distance_y[i] = Shot[i][j].y  - Back[pos].src_y;
		}
	}
}
/*****************************************************************
関数名	: GetWeapon 長尾　12/05　
機能	: 武器の変更
引数	: クライアントID
出力	: なし
*****************************************************************/
void GetWeapon(int pos){


}
/*****************************************************************
関数名	: HitJudge 長尾　12/09　
機能	: shotと壁やプレイヤーとの当たり判定
引数	: クライアントID
出力	: なし
*****************************************************************/
void HitJudge(int pos){

	int i,j;

	for(i=0;i<num_client;i++){
		for(j=0;j<MAX_BULLET;j++){
			if(Shot[pos][j].x < -10 || Shot[pos][j].x > STAGE_WIDTH ||
			 Shot[pos][j].y > STAGE_HEIGHT || Shot[pos][j].y < 0){ //画面外へ行ったら弾は消える
				Shot[pos][j].flag = 0;
				Shot[pos][j].x = -100;
				Shot[pos][j].y = -100;
			}
			if(Shot[pos][j].distance_x[i] < 40 && Shot[pos][j].distance_x[i] > 0 &&
			 Shot[pos][j].distance_y[i] < 40 && Shot[pos][j].distance_y[i] > 0 && pos != i){ //プレイヤーに当たったら弾は消え,hp-1
				Shot[i][j].flag = 0;//iは撃った方のクライアント（弾が当たったクライアントではない）
				Shot[i][j].x = -100;
				Shot[i][j].y = -100;
				Player[pos].hp -= 1;//posは弾が当たった方のクライアント
			}
		}
	}
}
/*****************************************************************
関数名	: GetRandomInt
機能	: 整数の乱数を得る
引数	: int	n	: 乱数の最大値
出力	: 乱数値
*****************************************************************/
static int GetRandomInt(int n)
{
    return rand()%n;
}

