/*****************************************************************
ファイル名	: client_func.h
機能		: クライアントの外部関数の定義
*****************************************************************/

#ifndef _CLIENT_FUNC_H_
#define _CLIENT_FUNC_H_

#include"common.h"

/* client_net.c */
extern int SetUpClient(char* hostName,int *clientID,int *num,char clientName[][MAX_NAME_SIZE]);
extern void CloseSoc(void);
extern int RecvIntData(int *intData);
extern void SendData(void *data,int dataSize);
extern int SendRecvManager(void);

/* client_win.c */
extern int InitWindows(int clientID,int num,char name[][MAX_NAME_SIZE]);
extern void DestroyWindow(void);
extern void WindowEvent(int num);
extern void MoveRight(int x,int y);
extern void MoveLeft(int x,int y);
extern void JumpAction(int x,int y);

extern void DrawPlayer(int i,int pos,int distance_x,int distance_y); /*長尾 11/20*/
extern void DrawPlayerArm(int i,int pos,int distance_x,int distance_y); /*長尾 12/02*/
extern void DrawShot(int i,int j,int pos,int distance_x,int distance_y);
extern void DrawPlayerHP(int i,int pos,int hp); /*長尾 12/09*/
extern int AllInit(void); /*長尾 11/20*/

extern void ClearScreen(int pos,int src_x,int src_y);/*長尾　11/26 画面を全て消す*/
extern int FlipScreen(void);/*長尾　11/26 SDL_Flip する*/

/* client_command.c */
extern int ExecuteCommand(char command);
extern void SendRightCommand(void);
extern void SendJumpCommand(void);
extern void SendLeftCommand(void);
extern void SendEndCommand(void);
extern void SendPointCommand(int mouse_x,int mouse_y);/*長尾 12/03*/
extern void SendShotCommand(void);/*長尾 12/04*/
extern void SendWeaponCommand(void);/*長尾 12/04*/

#endif

