/*****************************************************************
ファイル名	: common.h
機能		: サーバーとクライアントで使用する定数の宣言を行う
*****************************************************************/

#ifndef _COMMON_H_
#define _COMMON_H_

#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<sys/types.h>
#include<assert.h>
#include<math.h>

/*長尾 12/03 client_win.cから移動*/
#include<SDL/SDL.h>
#include<SDL/SDL_image.h>
#include<SDL/SDL_gfxPrimitives.h>
#include<SDL/SDL_rotozoom.h>
#include<SDL/SDL_ttf.h> // TrueTypeフォントを表示するために必要なヘッダ
#include<SDL/SDL_mixer.h> // SDLでサウンドを用いるために必要なヘッダファイルをインクルード

#define PORT		(u_short)8888	/* ポート番号 */

#define MAX_CLIENTS	4				/* クライアント数の最大値 */
#define MAX_NAME_SIZE	7 				/* ユーザー名の最大値*/
#define MAX_DATA	1200				/* 送受信するデータの最大値 */
#define MAX_BULLET	10				/* 各プレーヤーが画面に表示できる弾の数 */

#define WINDOW_WIDTH	800 				/* ウィンドウの幅*/
#define WINDOW_HEIGHT	600				/* ウィンドウの高さ */
#define STAGE_WIDTH	1600 				/* ステージの幅　ステージ外400×2除く*/
#define STAGE_HEIGHT	1000				/* ステージの高さ　ステージ外400×２除く */

#define END_COMMAND	'E'	 		/* プログラム終了コマンド */
#define LEFT_COMMAND	'L'			/* 左移動コマンド */
#define RIGHT_COMMAND	'R'			/* 右移動コマンド */
#define JUMP_COMMAND	'J'			/* ジャンプコマンド */
#define ALL_COMMAND	'A'			/* 常時送らなければならないコマンド 長尾　11/20*/
#define POINT_COMMAND	'M'			/* マウスポインタコマンド 長尾　12/03*/
#define SHOT_COMMAND	'S'			/* SHOTコマンド 長尾　12/04*/
#define WEAPON_COMMAND	'W'			/* 武器変更コマンド 長尾　12/04*/
#define TIME_COMMAND	'T'			/* 時刻送受信コマンド 長尾　12/09*/

extern int num_client; /*クライアントの人数*/
extern int timer; /*時刻*/
extern int order; /*どこでも使えるクライアントID*/

//長尾　11/12 自機構造体
typedef struct{
	int x; //自機座標　自機は実質画面の真ん中に固定なので値は一定　Back.src_xが移動座標である　
	int y;
	int speed; //自機速度
	int ax; //x加速度
	int ay; //ｙ加速度
	int jump; //ジャンプ力
	int jumpflag; //ジャンプフラグ
	int distance_x[MAX_CLIENTS];  //プレーヤー間の距離差
	int distance_y[MAX_CLIENTS];  //プレーヤー間の距離差
	int hp;
	char *name; //キャラの名前
	double spd; //速度
	SDL_Surface *ziki; //自機画像
	SDL_Surface *names; // 名前画像へのポインタ
	SDL_Surface *ikon; // アイコン画像データへのポインタ
	SDL_Rect src_rect_player;//自機切り取り座標 
	SDL_Rect dst_rect_player;//自機描写座標
	SDL_Rect src_rect_other_player;//他の自機切り取り座標 
	SDL_Rect dst_rect_other_player;//他の自機描写座標
	SDL_Rect dst_rect_name;//名前描写座標
	SDL_Rect dst_rect_ikon;//自機の上に出るアイコン
}PlayerData;

extern PlayerData Player[MAX_CLIENTS]; //自機

//長尾　12/03 自機アーム構造体
typedef struct{
	int x;
	int y;
	int angle;
	SDL_Surface *arm; //アーム画像
	SDL_Surface *arm_resized; //アームの角度を変えたもの
	SDL_Rect src_rect_player_arm;//アーム切り取り座標 
	SDL_Rect dst_rect_player_arm;//アーム描写座標
}PlayerArmData;

extern PlayerArmData PlayerArm[MAX_CLIENTS]; //自機アーム

//長尾　11/21 自分のフレーム構造体
typedef struct{
	SDL_Surface *win; //今だけ画像
	SDL_Surface *lose; //今だけ画像
	SDL_Surface *flame; //フレーム画像
	SDL_Surface *log; //キルログ画像
	SDL_Surface *p1log; //1p画像
	SDL_Surface *p2log; //2p画像
	SDL_Surface *p3log; //3p画像
	SDL_Surface *p4log; //4p画像
	SDL_Surface *winlog; //winP画像
	SDL_Surface *loselog; //loseP画像
	SDL_Rect src_rect_flame;//フレーム切り取り描写座標
	SDL_Rect dst_rect_flame;//フレーム描写座標
	SDL_Rect dst_rect_log;//ログ描写座標
	SDL_Rect dst_rect_winlog;//ログ　倒した方の描写座標
	SDL_Rect dst_rect_loselog;//ログ　倒された方の描写座標
}FlameData;

extern FlameData Flame; //自分のフレーム

//長尾　11/26 背景構造体
typedef struct{
	int src_x;
	int src_y;
	int ay; //ｙ加速度
	SDL_Surface *back; //背景画像
	SDL_Rect src_rect_back;//背景切り取り座標
	SDL_Rect dst_rect_back;//背景描写座標
}BackData;

extern BackData Back[MAX_CLIENTS]; //背景

//長尾　12/03 マウス構造体
typedef struct{
	int x;
	int y;
	double A_angle; //弧度法の角度  弧度法の角度doubleをサーバ上で度数法の角度intに変えてclientに送る
	int B_angle; //度数法の角度
}MouseData;

extern MouseData Mouse[MAX_CLIENTS]; //マウス

//長尾　12/04　武器（SHOT）構造体
typedef struct{
	int x;
	int y;
	double A_angle; //弧度法の角度  弧度法の角度doubleをサーバ上で度数法の角度intに変えてclientに送る　shotの移動にも用いる
	int B_angle; //度数法の角度
	int flag;
	int distance_x[MAX_CLIENTS];  //プレーヤーとSHOT間の距離差
	int distance_y[MAX_CLIENTS];  //プレーヤーとSHOT間の距離差
	SDL_Surface *shot; //SHOT画像
	SDL_Surface *shot_resized; //SHOTの角度を変えたもの
	SDL_Rect src_rect_shot;//SHOT切り取り座標 
	SDL_Rect dst_rect_shot;//SHOT描写座標
}ShotData;

extern ShotData Shot[MAX_CLIENTS][MAX_BULLET]; //SHOT



#endif
